- To run the code:
1. cd to this directory
2. Run the following command:
```
python3 src/main1.py
python3 src/main2.py
python3 src/main3.py
```
